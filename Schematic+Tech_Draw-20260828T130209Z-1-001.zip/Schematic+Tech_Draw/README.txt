﻿File schematic là file mô phỏng nguyên lý hoạt động và cách nối dây của mạch cũng như sử dụng để thiết kế mạch in(PCB)
File Tech drawing sử dụng để mô tả hình dáng và thiết kế bên trong lẫn bên ngoài của hộp
